package com.graymatter.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Employee_managementApplication {

	public static void main(String[] args) {
		SpringApplication.run(Employee_managementApplication.class, args);
	}

}
